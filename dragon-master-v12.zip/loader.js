// Injects main.js into the page's own JS world so it can wrap getUserMedia / RTCPeerConnection.
(function () {
  try {
    var s = document.createElement('script');
    s.src = chrome.runtime.getURL('main.js');
    s.async = false;
    s.onload = function () { s.remove(); };
    (document.head || document.documentElement).appendChild(s);
  } catch (e) {}
})();
