/* DRAGON MASTER v12 - Messenger voice booster by MAHIR
 * Quetta-style UI, low-lag audio graph, network assist (Opus tuning + bitrate caps).
 * Runs in the page world: wraps getUserMedia + RTCPeerConnection.
 */
(() => {
  'use strict';
  if (window.__DRAGON_MASTER__) return;
  try { Object.defineProperty(window, '__DRAGON_MASTER__', { value: true }); } catch (e) { window.__DRAGON_MASTER__ = true; }

  const PRESETS = [1, 10, 50, 150, 400, 1000];
  const LABELS = ['Normal', 'Clear', 'Loud', 'Heavy', 'Ultra', 'Max'];
  const STORE = 'dm12';

  /* ---------------- state ---------------- */
  const S = { on: true, gain: 150, limiter: true, net: true, monitor: false, fileVol: 100, loop: false, fabY: 0.6 };
  try { Object.assign(S, JSON.parse(localStorage.getItem(STORE) || '{}')); } catch (e) {}
  S.gain = Math.min(1000, Math.max(1, Math.round(+S.gain) || 150));
  S.fileVol = Math.min(300, Math.max(0, Math.round(+S.fileVol) || 100));
  S.fabY = Math.min(0.9, Math.max(0.08, +S.fabY || 0.6));
  const save = () => { try { localStorage.setItem(STORE, JSON.stringify(S)); } catch (e) {} };

  /* ---------------- audio engine ---------------- */
  let ctx = null, hp, micGain, fileGain, mix, comp, out, dest, monGain, analyser, micSrc = null;

  function initAudio() {
    if (ctx) return ctx;
    const AC = window.AudioContext || window.webkitAudioContext;
    try { ctx = new AC({ latencyHint: 'interactive', sampleRate: 48000 }); }
    catch (e) { ctx = new AC({ latencyHint: 'interactive' }); }

    hp = ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 90; hp.Q.value = 0.7;
    micGain = ctx.createGain();
    fileGain = ctx.createGain();
    mix = ctx.createGain();
    comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -8; comp.knee.value = 0; comp.ratio.value = 20;
    comp.attack.value = 0.002; comp.release.value = 0.08;
    out = ctx.createGain();
    analyser = ctx.createAnalyser(); analyser.fftSize = 256;
    dest = ctx.createMediaStreamDestination();
    monGain = ctx.createGain();

    hp.connect(micGain); micGain.connect(mix);
    fileGain.connect(mix);
    fileGain.connect(monGain); monGain.connect(ctx.destination);
    out.connect(dest); out.connect(analyser);
    route(); applyGain(); applyFile();
    return ctx;
  }

  function route() {
    if (!ctx) return;
    try { mix.disconnect(); } catch (e) {}
    try { comp.disconnect(); } catch (e) {}
    if (S.limiter) { mix.connect(comp); comp.connect(out); } else { mix.connect(out); }
  }
  function applyGain() {
    if (!ctx) return;
    micGain.gain.setTargetAtTime(S.on ? S.gain : 1, ctx.currentTime, 0.015);
  }
  function applyFile() {
    if (!ctx) return;
    fileGain.gain.setTargetAtTime(S.fileVol / 100, ctx.currentTime, 0.015);
    monGain.gain.setTargetAtTime(S.monitor ? 1 : 0, ctx.currentTime, 0.015);
  }
  const wake = () => { if (ctx && ctx.state !== 'running') ctx.resume().catch(() => {}); };
  ['pointerdown', 'touchend', 'keydown'].forEach((ev) => addEventListener(ev, wake, { capture: true, passive: true }));

  /* ---------------- getUserMedia hook ---------------- */
  const md = navigator.mediaDevices;
  if (md && md.getUserMedia) {
    const orig = md.getUserMedia.bind(md);
    md.getUserMedia = async function (c) {
      if (!c || !c.audio) return orig(c);
      let cc = c;
      try {
        const a = c.audio === true ? {} : Object.assign({}, c.audio);
        const ideal = (k, v) => { if (!(k in a)) a[k] = { ideal: v }; };
        ideal('echoCancellation', true); ideal('noiseSuppression', true);
        ideal('autoGainControl', false); ideal('channelCount', 1);
        cc = Object.assign({}, c, { audio: a });
      } catch (e) { cc = c; }
      let stream;
      try { stream = await orig(cc); }
      catch (e) {
        if (e && e.name === 'OverconstrainedError') stream = await orig(c); else throw e;
      }
      try {
        const at = stream.getAudioTracks();
        if (!at.length) return stream;
        initAudio();
        if (ctx.state !== 'running') {
          await Promise.race([ctx.resume().catch(() => {}), new Promise((r) => setTimeout(r, 350))]);
        }
        if (ctx.state !== 'running') return stream; // never leave the user with a silent mic
        if (micSrc) { try { micSrc.disconnect(); } catch (e) {} }
        micSrc = ctx.createMediaStreamSource(new MediaStream([at[0]]));
        micSrc.connect(hp);
        const outTracks = dest.stream.getAudioTracks().map((t) => {
          const c2 = t.clone();
          const st = c2.stop.bind(c2);
          c2.stop = () => { st(); at.forEach((x) => { try { x.stop(); } catch (e) {} }); };
          return c2;
        });
        return new MediaStream(outTracks.concat(stream.getVideoTracks()));
      } catch (e) { return stream; }
    };
  }

  /* ---------------- network assist ---------------- */
  function tuneSdp(sdp) {
    const m = /a=rtpmap:(\d+) opus\/48000\/2/i.exec(sdp);
    if (!m) return sdp;
    const pt = m[1];
    const want = { useinbandfec: '1', usedtx: '0', stereo: '0', 'sprop-stereo': '0', maxaveragebitrate: '48000', maxplaybackrate: '48000', minptime: '20' };
    const re = new RegExp('a=fmtp:' + pt + ' ([^\\r\\n]*)');
    const f = re.exec(sdp);
    if (f) {
      const map = {};
      f[1].split(';').forEach((kv) => { const i = kv.indexOf('='); if (i > 0) map[kv.slice(0, i).trim()] = kv.slice(i + 1).trim(); });
      Object.assign(map, want);
      const line = 'a=fmtp:' + pt + ' ' + Object.keys(map).map((k) => k + '=' + map[k]).join(';');
      return sdp.replace(re, line);
    }
    const line = 'a=fmtp:' + pt + ' ' + Object.keys(want).map((k) => k + '=' + want[k]).join(';');
    return sdp.replace(new RegExp('(a=rtpmap:' + pt + ' opus/48000/2\\r?\\n)'), '$1' + line + '\r\n');
  }

  function tuneSenders(pc) {
    if (!S.net) return;
    let senders = [];
    try { senders = pc.getSenders(); } catch (e) { return; }
    senders.forEach((s) => {
      const t = s.track;
      if (!t || !s.getParameters) return;
      try {
        const p = s.getParameters();
        if (!p.encodings || !p.encodings.length) p.encodings = [{}];
        p.encodings.forEach((e) => {
          if (t.kind === 'audio') { e.maxBitrate = 48000; e.networkPriority = 'high'; e.priority = 'high'; }
          else { e.maxBitrate = Math.min(e.maxBitrate || 1e9, 700000); e.maxFramerate = 24; }
        });
        if (t.kind === 'video') p.degradationPreference = 'maintain-framerate';
        s.setParameters(p).catch(() => {});
      } catch (e) {}
    });
  }
  const pending = new WeakSet();
  function scheduleTune(pc) {
    if (pending.has(pc)) return;
    pending.add(pc);
    [300, 2500, 8000].forEach((ms) => setTimeout(() => tuneSenders(pc), ms));
    setTimeout(() => pending.delete(pc), 9000);
  }

  const PC = window.RTCPeerConnection;
  if (PC && PC.prototype) {
    const sld = PC.prototype.setLocalDescription;
    PC.prototype.setLocalDescription = function (desc, ...rest) {
      try { if (S.net && desc && typeof desc.sdp === 'string' && desc.sdp) desc = { type: desc.type, sdp: tuneSdp(desc.sdp) }; } catch (e) {}
      const p = sld.call(this, desc, ...rest);
      if (p && p.then) p.then(() => scheduleTune(this), () => {});
      return p;
    };
    const srd = PC.prototype.setRemoteDescription;
    PC.prototype.setRemoteDescription = function (...a) {
      const p = srd.apply(this, a);
      if (p && p.then) p.then(() => scheduleTune(this), () => {});
      return p;
    };
  }

  /* ---------------- file player ---------------- */
  let fEl = null, fSrc = null, fName = '';
  function loadFile(file) {
    initAudio(); wake();
    if (fEl) { try { fEl.pause(); } catch (e) {} try { fSrc.disconnect(); } catch (e) {} try { URL.revokeObjectURL(fEl.src); } catch (e) {} }
    fEl = document.createElement('video');
    fEl.playsInline = true; fEl.preload = 'auto'; fEl.loop = !!S.loop;
    fEl.src = URL.createObjectURL(file);
    fSrc = ctx.createMediaElementSource(fEl);
    fSrc.connect(fileGain);
    fName = file.name;
    ['play', 'pause', 'ended', 'loadedmetadata'].forEach((ev) => fEl.addEventListener(ev, refreshPlayer));
    fEl.addEventListener('timeupdate', refreshSeek);
    refreshPlayer();
  }

  /* ---------------- UI (Quetta style) ---------------- */
  const CSS = `
  :host{all:initial}
  *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
  .root{--bg:#0d0508;--card:#212121;--tile:#2b2b2b;--line:#343434;--txt:#f3f3f3;--dim:#9a9a9a;--ac:#e5496b;--acd:rgba(229,73,107,.16);
    font:15px/1.3 Roboto,system-ui,-apple-system,"Segoe UI",sans-serif;color:var(--txt);position:fixed;inset:0;pointer-events:none;z-index:2147483647}
  .fab{position:fixed;right:12px;width:54px;height:54px;border-radius:50%;background:var(--card);border:2px solid var(--ac);color:var(--ac);
    display:flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;pointer-events:auto;touch-action:none;user-select:none;contain:layout paint}
  .fab.live{background:var(--ac);color:#fff}
  .scrim{position:fixed;inset:0;background:rgba(0,0,0,.5);opacity:0;transition:opacity .2s;pointer-events:none}
  .open .scrim{opacity:1;pointer-events:auto}
  .sheet{position:fixed;left:0;right:0;bottom:0;margin:0 auto;max-width:460px;max-height:88vh;overflow-y:auto;overscroll-behavior:contain;
    background:var(--bg);border-radius:28px 28px 0 0;padding:8px 14px calc(18px + env(safe-area-inset-bottom));
    transform:translateY(105%);transition:transform .22s ease-out;pointer-events:auto;contain:layout style}
  .open .sheet{transform:translateY(0)}
  .sheet.drag{transition:none}
  .grab{height:26px;display:flex;align-items:center;justify-content:center;touch-action:none}
  .grab i{width:44px;height:4px;border-radius:4px;background:#555}
  .head{display:flex;align-items:center;justify-content:space-between;padding:2px 6px 12px}
  .ttl{color:var(--ac);font-weight:700;font-size:18px;letter-spacing:.4px}
  .sub{color:var(--dim);font-size:12px;margin-top:2px}
  .ver{color:var(--dim);font-size:12px;border:1px solid var(--line);border-radius:12px;padding:3px 9px}
  .card{background:var(--card);border-radius:28px;padding:12px;margin-bottom:12px}
  .tiles{display:grid;grid-template-columns:repeat(3,1fr);gap:9px}
  .tile{all:unset;box-sizing:border-box;background:var(--tile);border-radius:22px;height:72px;display:flex;flex-direction:column;
    align-items:center;justify-content:center;gap:4px;cursor:pointer;border:1.5px solid transparent}
  .tile b{font-size:21px;font-weight:700}
  .tile span{font-size:11px;color:var(--dim)}
  .tile.act{background:var(--acd);border-color:var(--ac)}
  .tile.act b{color:var(--ac)}
  .tile:active{filter:brightness(1.25)}
  .hr{height:1px;background:var(--line);margin:12px 4px}
  .row{display:flex;align-items:center;gap:14px;padding:11px 6px;cursor:pointer}
  .row+.row{border-top:1px solid var(--line)}
  .ic{width:24px;height:24px;flex:none;color:#ddd}
  .ic svg{width:24px;height:24px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
  .rt{flex:1;min-width:0}
  .rt b{display:block;font-weight:500;font-size:16px}
  .rt small{display:block;color:var(--dim);font-size:12px;margin-top:1px}
  .sw{appearance:none;-webkit-appearance:none;width:46px;height:27px;border-radius:14px;background:#3c3c3c;position:relative;flex:none;margin:0;outline:0;cursor:pointer;transition:background .15s}
  .sw::after{content:"";position:absolute;top:3px;left:3px;width:21px;height:21px;border-radius:50%;background:#bbb;transition:transform .15s,background .15s}
  .sw:checked{background:var(--ac)}
  .sw:checked::after{transform:translateX(19px);background:#fff}
  .slrow{display:flex;justify-content:space-between;align-items:baseline;padding:0 6px;color:var(--dim);font-size:13px}
  .slrow b{color:var(--ac);font-size:18px}
  input[type=range]{-webkit-appearance:none;appearance:none;width:100%;height:30px;background:transparent;margin:2px 0;outline:0}
  input[type=range]::-webkit-slider-runnable-track{height:5px;border-radius:5px;background:#3a3a3a}
  input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:22px;height:22px;border-radius:50%;background:var(--ac);margin-top:-8.5px;border:0}
  .meter{height:6px;border-radius:6px;background:#2f2f2f;margin:6px 6px 4px;overflow:hidden}
  .meter i{display:block;height:100%;width:100%;background:var(--ac);transform-origin:left;transform:scaleX(0)}
  .pink{all:unset;box-sizing:border-box;width:100%;display:flex;align-items:center;justify-content:center;gap:10px;height:50px;border-radius:18px;
    background:var(--acd);color:var(--ac);font-weight:500;font-size:15px;cursor:pointer}
  .pink svg{width:22px;height:22px;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}
  .pink:active{filter:brightness(1.3)}
  .player{display:none;margin-top:10px}
  .player.on{display:block}
  .fn{padding:2px 6px 6px;font-size:13px;color:var(--dim);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .ctl{display:flex;gap:10px;align-items:center;padding:0 2px}
  .rb{all:unset;box-sizing:border-box;width:46px;height:46px;border-radius:50%;background:var(--tile);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;flex:none}
  .rb.main{background:var(--ac)}
  .rb.sel{background:var(--acd);color:var(--ac)}
  .rb svg{width:22px;height:22px;fill:currentColor}
  .rb:active{filter:brightness(1.3)}
  .vol{display:flex;align-items:center;gap:8px;padding:2px 6px;color:var(--dim);font-size:12px}
  .vol input{flex:1}
  .note{color:var(--dim);font-size:11.5px;text-align:center;padding:2px 10px 0}
  `;

  const I = {
    mic: '<svg viewBox="0 0 24 24"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>',
    shield: '<svg viewBox="0 0 24 24"><path d="M12 3l7 3v5c0 5-3 8-7 10-4-2-7-5-7-10V6z"/><path d="M9 12l2 2 4-4"/></svg>',
    net: '<svg viewBox="0 0 24 24"><path d="M3 9a14 14 0 0 1 18 0M6 12.5a9.5 9.5 0 0 1 12 0M9 16a5 5 0 0 1 6 0"/><circle cx="12" cy="19" r="1"/></svg>',
    spk: '<svg viewBox="0 0 24 24"><path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16.5 8.5a5 5 0 0 1 0 7"/></svg>',
    file: '<svg viewBox="0 0 24 24"><path d="M12 16V4M7 9l5-5 5 5"/><path d="M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3"/></svg>',
    play: '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>',
    pause: '<svg viewBox="0 0 24 24"><path d="M7 5h4v14H7zM13 5h4v14h-4z"/></svg>',
    stop: '<svg viewBox="0 0 24 24"><rect x="6" y="6" width="12" height="12" rx="1.5"/></svg>',
    loop: '<svg viewBox="0 0 24 24" style="fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round"><path d="M17 2l4 4-4 4"/><path d="M3 11V9a3 3 0 0 1 3-3h15M7 22l-4-4 4-4"/><path d="M21 13v2a3 3 0 0 1-3 3H3"/></svg>'
  };

  const HTML = `
  <div class="root" id="root">
    <div class="fab" id="fab"><span id="fabTxt">150x</span></div>
    <div class="scrim" id="scrim"></div>
    <div class="sheet" id="sheet">
      <div class="grab" id="grab"><i></i></div>
      <div class="head"><div><div class="ttl">DRAGON MASTER</div><div class="sub">Messenger voice booster by MAHIR</div></div><div class="ver">v12</div></div>

      <div class="card">
        <div class="tiles" id="tiles"></div>
        <div class="hr"></div>
        <div class="slrow"><span>Custom boost</span><b id="gv">150x</b></div>
        <input type="range" id="rg" min="0" max="1000" step="1">
        <div class="meter"><i id="mt"></i></div>
        <label class="row"><span class="ic">${I.mic}</span><span class="rt"><b>Voice boost</b><small>Turn off to send normal 1x voice</small></span><input type="checkbox" class="sw" data-k="on"></label>
      </div>

      <div class="card">
        <label class="row"><span class="ic">${I.shield}</span><span class="rt"><b>Clean limiter</b><small>Stops crackle and distortion at high boost</small></span><input type="checkbox" class="sw" data-k="limiter"></label>
        <label class="row"><span class="ic">${I.net}</span><span class="rt"><b>Network assist</b><small>Stable voice, lighter video, less lag</small></span><input type="checkbox" class="sw" data-k="net"></label>
      </div>

      <div class="card">
        <button class="pink" id="pick">${I.file}<span>Add audio / video to call</span></button>
        <input type="file" id="file" accept="audio/*,video/*" hidden>
        <div class="player" id="player">
          <div class="fn" id="fn"></div>
          <div class="ctl">
            <button class="rb main" id="pp"></button>
            <button class="rb" id="st">${I.stop}</button>
            <button class="rb" id="lp">${I.loop}</button>
            <input type="range" id="sk" min="0" max="1000" value="0">
          </div>
          <div class="vol"><span>Vol</span><input type="range" id="fv" min="0" max="300" step="1"><b id="fvv" style="color:var(--ac);min-width:42px;text-align:right"></b></div>
          <label class="row"><span class="ic">${I.spk}</span><span class="rt"><b>Hear it myself</b><small>Off = only the call hears it</small></span><input type="checkbox" class="sw" data-k="monitor"></label>
        </div>
      </div>
      <div class="note">If a call was already running, reload the page once so the boost can attach.</div>
    </div>
  </div>`;

  let $ = null, host = null, meterTimer = 0, isOpen = false;
  const gainToPos = (g) => Math.round((Math.log10(g) / 3) * 1000);
  const posToGain = (p) => Math.min(1000, Math.max(1, Math.round(Math.pow(10, (p / 1000) * 3))));
  const fmt = (t) => { t = Math.floor(t || 0); return Math.floor(t / 60) + ':' + String(t % 60).padStart(2, '0'); };

  function refreshGain() {
    if (!$) return;
    const g = S.gain;
    $('gv').textContent = g + 'x';
    $('rg').value = gainToPos(g);
    $('fabTxt').textContent = S.on ? g + 'x' : 'OFF';
    $('fab').classList.toggle('live', !!(S.on && g > 1));
    $('tiles').querySelectorAll('.tile').forEach((t) => t.classList.toggle('act', +t.dataset.g === g));
  }
  function refreshPlayer() {
    if (!$) return;
    $('player').classList.toggle('on', !!fEl);
    if (!fEl) return;
    $('fn').textContent = fName + (isFinite(fEl.duration) ? '  ·  ' + fmt(fEl.duration) : '');
    $('pp').innerHTML = fEl.paused ? I.play : I.pause;
    $('lp').classList.toggle('sel', !!S.loop);
    $('fv').value = S.fileVol; $('fvv').textContent = S.fileVol + '%';
  }
  function refreshSeek() {
    if (!$ || !fEl || !isOpen || !isFinite(fEl.duration) || !fEl.duration) return;
    $('sk').value = Math.round((fEl.currentTime / fEl.duration) * 1000);
  }
  function refreshSwitches() {
    $('root').querySelectorAll('.sw').forEach((c) => { c.checked = !!S[c.dataset.k]; });
  }
  function setGain(g) { S.gain = Math.min(1000, Math.max(1, g)); applyGain(); refreshGain(); save(); }

  function meterStart() {
    if (meterTimer) return;
    const buf = new Uint8Array(128);
    meterTimer = setInterval(() => {
      if (!analyser) { $('mt').style.transform = 'scaleX(0)'; return; }
      analyser.getByteTimeDomainData(buf);
      let pk = 0; for (let i = 0; i < buf.length; i++) { const v = Math.abs(buf[i] - 128); if (v > pk) pk = v; }
      $('mt').style.transform = 'scaleX(' + Math.min(1, pk / 100).toFixed(2) + ')';
    }, 110);
  }
  function meterStop() { clearInterval(meterTimer); meterTimer = 0; }

  function setOpen(v) {
    isOpen = v;
    $('root').classList.toggle('open', v);
    if (v) { refreshGain(); refreshPlayer(); refreshSeek(); meterStart(); } else meterStop();
  }

  function positionFab() { $('fab').style.top = Math.round(S.fabY * innerHeight - 27) + 'px'; }

  function buildUI() {
    if (host || !document.documentElement) return;
    host = document.createElement('div');
    host.setAttribute('style', 'all:initial');
    const root = host.attachShadow({ mode: 'open' });
    try { const sh = new CSSStyleSheet(); sh.replaceSync(CSS); root.adoptedStyleSheets = [sh]; }
    catch (e) { const st = document.createElement('style'); st.textContent = CSS; root.appendChild(st); }
    const wrap = document.createElement('div'); wrap.innerHTML = HTML; root.appendChild(wrap.firstElementChild || wrap);
    $ = (id) => root.getElementById ? root.getElementById(id) : root.querySelector('#' + id);
    // shadowRoot has no getElementById in some engines: fallback above.
    document.documentElement.appendChild(host);

    $('tiles').innerHTML = PRESETS.map((g, i) => `<button class="tile" data-g="${g}"><b>${g}x</b><span>${LABELS[i]}</span></button>`).join('');
    $('tiles').addEventListener('click', (e) => { const b = e.target.closest('.tile'); if (b) { initAudio(); wake(); setGain(+b.dataset.g); } });
    $('rg').addEventListener('input', (e) => setGain(posToGain(+e.target.value)));
    root.addEventListener('change', (e) => {
      const k = e.target && e.target.dataset && e.target.dataset.k; if (!k) return;
      S[k] = e.target.checked; save();
      if (k === 'on') { initAudio(); applyGain(); refreshGain(); }
      if (k === 'limiter') route();
      if (k === 'monitor') applyFile();
    });
    $('scrim').addEventListener('click', () => setOpen(false));

    // file player
    $('pick').addEventListener('click', () => $('file').click());
    $('file').addEventListener('change', (e) => { const f = e.target.files && e.target.files[0]; if (f) { loadFile(f); } e.target.value = ''; });
    $('pp').addEventListener('click', () => { if (!fEl) return; wake(); fEl.paused ? fEl.play().catch(() => {}) : fEl.pause(); });
    $('st').addEventListener('click', () => { if (!fEl) return; fEl.pause(); fEl.currentTime = 0; refreshSeek(); });
    $('lp').addEventListener('click', () => { S.loop = !S.loop; if (fEl) fEl.loop = S.loop; save(); refreshPlayer(); });
    $('sk').addEventListener('input', (e) => { if (fEl && isFinite(fEl.duration)) fEl.currentTime = (e.target.value / 1000) * fEl.duration; });
    $('fv').addEventListener('input', (e) => { S.fileVol = +e.target.value; applyFile(); $('fvv').textContent = S.fileVol + '%'; save(); });

    // swipe the handle down to close
    const sheet = $('sheet'); let y0 = 0, dy = 0, dragging = false;
    $('grab').addEventListener('pointerdown', (e) => { dragging = true; y0 = e.clientY; dy = 0; sheet.classList.add('drag'); e.target.setPointerCapture && e.target.setPointerCapture(e.pointerId); });
    $('grab').addEventListener('pointermove', (e) => { if (!dragging) return; dy = Math.max(0, e.clientY - y0); sheet.style.transform = 'translateY(' + dy + 'px)'; });
    const endDrag = () => { if (!dragging) return; dragging = false; sheet.classList.remove('drag'); sheet.style.transform = ''; if (dy > 80) setOpen(false); };
    $('grab').addEventListener('pointerup', endDrag); $('grab').addEventListener('pointercancel', endDrag);

    // floating button: tap to open, drag up/down to move
    const fab = $('fab'); let fy = 0, moved = false, fdown = false;
    fab.addEventListener('pointerdown', (e) => { fdown = true; moved = false; fy = e.clientY; fab.setPointerCapture(e.pointerId); });
    fab.addEventListener('pointermove', (e) => {
      if (!fdown) return;
      if (Math.abs(e.clientY - fy) > 8) moved = true;
      if (moved) { S.fabY = Math.min(0.92, Math.max(0.08, e.clientY / innerHeight)); positionFab(); }
    });
    fab.addEventListener('pointerup', () => { if (!fdown) return; fdown = false; if (moved) save(); else { initAudio(); wake(); setOpen(true); } });
    fab.addEventListener('pointercancel', () => { fdown = false; });
    addEventListener('resize', positionFab, { passive: true });

    positionFab(); refreshGain(); refreshSwitches(); refreshPlayer();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', buildUI, { once: true });
  else buildUI();
  // documentElement exists at document_start, so also try right away.
  buildUI();
})();
